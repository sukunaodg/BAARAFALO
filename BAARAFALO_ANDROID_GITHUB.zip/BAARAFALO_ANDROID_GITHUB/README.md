# BAARAFALO Android

Projet Android WebView qui embarque l'interface BAARAFALO dans `app/src/main/assets/index.html`.

## Compilation automatique
1. Importer tous les fichiers de ce dépôt dans GitHub.
2. Ouvrir l'onglet Actions.
3. Lancer `Build BAARAFALO APK` avec `Run workflow`, ou pousser un commit sur `main`.
4. Télécharger l'artefact `BAARAFALO-debug-apk` à la fin du workflow.

L'APK debug est destinée aux tests. Une version de publication doit être signée avec une clé privée conservée hors du dépôt.
